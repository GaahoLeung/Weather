package mg.studio.weatherappdesign;

import android.icu.util.Calendar;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        new DownloadUpdate().execute();




    }

    public void btnClick(View view) {

        new DownloadUpdate().execute();
    }


    private class DownloadUpdate extends AsyncTask<String, Void, String> {


        @Override
        protected String doInBackground(String... strings) {
            String stringUrl = "https://cqu.andream.app/weather";
            HttpURLConnection urlConnection = null;
            BufferedReader reader;

            try {
                URL url = new URL(stringUrl);

                // Create the request to get the information from the server, and open the connection
                urlConnection = (HttpURLConnection) url.openConnection();

                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                // Read the input stream into a String
                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();
                if (inputStream == null) {
                    // Nothing to do.
                    return null;
                }
                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    // Mainly needed for debugging
                    buffer.append(line).append("\n");
                }

                if (buffer.length() == 0) {
                    // Stream was empty.  No point in parsing.

                    return null;
                }

                return buffer.toString();

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }

        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        protected void onPostExecute(String buffer) {
            //Update the temperature displayed
            if (buffer==null){Toast.makeText(getApplicationContext(),"failed to connect",Toast.LENGTH_LONG).show();}
            else{
            try {
                JSONObject jsonObject=new JSONObject(buffer);
                //标示温度
                String nowTempu= String.valueOf(jsonObject.getInt("temperature"));
                ((TextView)findViewById(R.id.temperature_of_the_day)).setText(nowTempu);
                //标示地址
                String nowLocation= jsonObject.getString("location");
                ((TextView)findViewById(R.id. tv_location)).setText(nowLocation);
                //标示日期
                JSONArray dailyWeather= jsonObject.getJSONArray("daily");
                String nowDate=dailyWeather.getJSONObject(0).getString("date");
                ((TextView)findViewById(R.id. tv_date)).setText(nowDate);
                //标示周天
                String capWeek[] = {"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
                String week[] = {"SUN","MON","TUE","WED","THU","FRI","SAT","SUN","MON","TUE","WED","THU","FRI","SAT"};
                Calendar cal = Calendar.getInstance();
                int i = cal.get(Calendar.DAY_OF_WEEK);
                ((TextView) findViewById(R.id.Weekday)).setText(capWeek[i-1]);
                ((TextView) findViewById(R.id.tomorrow)).setText(week[i]);
                ((TextView) findViewById(R.id.dayAfterTomorrow)).setText(week[i+1]);
                ((TextView) findViewById(R.id.afterThirdDay)).setText(week[i+2]);
                ((TextView) findViewById(R.id.afterFourthDay)).setText(week[i+3]);
                //换图片
                String weatherCode="weather_"+dailyWeather.getJSONObject(0).getString("code_day");
                int resID = getResId(weatherCode, R.drawable.class);//获取res资源id的函数
                ImageView imageView=(ImageView)findViewById(R.id.img_weather_condition);
                imageView.setImageResource(resID);

                weatherCode="weather_"+dailyWeather.getJSONObject(1).getString("code_day");
                resID = getResId(weatherCode, R.drawable.class);//获取res资源id的函数
                imageView=(ImageView)findViewById(R.id.tomorrowImage);
                imageView.setImageResource(resID);

                weatherCode="weather_"+dailyWeather.getJSONObject(2).getString("code_day");
                resID = getResId(weatherCode, R.drawable.class);//获取res资源id的函数
                imageView=(ImageView)findViewById(R.id.dayAfterTomorrowImage);
                imageView.setImageResource(resID);

                weatherCode="weather_"+dailyWeather.getJSONObject(3).getString("code_day");
                resID = getResId(weatherCode, R.drawable.class);//获取res资源id的函数
                imageView=(ImageView)findViewById(R.id.afterThirdDayImage);
                imageView.setImageResource(resID);

                weatherCode="weather_"+dailyWeather.getJSONObject(4).getString("code_day");
                resID = getResId(weatherCode, R.drawable.class);//获取res资源id的函数
                imageView=(ImageView)findViewById(R.id.afterFourthDayImage);
                imageView.setImageResource(resID);

                Toast.makeText(getApplicationContext(),"updated", Toast.LENGTH_LONG).show();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            }

        }

        int getResId(String weatherCode, Class<R.drawable> drawableClass) {
            try {
                Field idField = R.drawable.class.getDeclaredField(weatherCode);
                return idField.getInt(idField);
            } catch (Exception e) {
                e.printStackTrace();
                return -1;
            }
        }

    }
}
