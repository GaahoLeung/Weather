package mg.studio.weatherappdesign.db;

public class province  {
}
