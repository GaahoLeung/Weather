import org.json.JSONException;
import org.json.JSONObject;


public class Refresh {
    public void getweather(String args[]){
        String url ="http://api.openweathermap.org/data/2.5/forecast?q=Chongqing,cn&mode=json&APPID=aa3d744dc145ef9d350be4a80b16ecab";
        int centigrade;
        String weather;


    }
}
