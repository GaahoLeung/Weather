## Weather application

The layout of this application is based on the use of a LinearLayout. 

Redesign the same application using a constraint-layout.

Read more at https://developer.android.com/training/constraint-layout

![Design](linear-layout.gif)

